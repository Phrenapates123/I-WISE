<!-- index.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BookWise - Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="login-page">
    <div class="login-container">
        <img src="sti-logo.png" alt="STI Logo" class="sti-logo">
        <img src="bookwise-logo.png" alt="BookWise Logo" class="bookwise-logo">
        <div class="login-box">
            <h2>Login</h2>
            <p>Sign in using your STI Office 365 account to access BookWise.</p>
            <button class="login-btn">Use Office 365 Login</button>
        </div>
    </div>
</body>
</html>