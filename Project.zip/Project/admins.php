<?php include('Overview/header.php'); ?>
<?php include('Overview/sidebar.php'); ?>

<link rel="stylesheet" href="style.css">

<div class="main-content">
    <h1>Admins</h1>
    <div class="item-list">
        <?php for ($i = 1; $i <= 3; $i++): ?>
        <div class="item-card">
            <div class="item-image"></div>
            <div class="item-info">
                <h3>Admin <?= $i ?></h3>
                <p>Admin Description</p>
            </div>
        </div>
        <?php endfor; ?>
    </div>
</div>