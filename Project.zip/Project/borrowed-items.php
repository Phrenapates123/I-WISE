<?php include('Overview/header.php'); ?>
<?php include('Overview/sidebar.php'); ?>

<link rel="stylesheet" href="style.css">


<div class="main-content">
    <h1>Borrowed Items</h1>
    <div class="item-list">
        <?php for ($i = 1; $i <= 3; $i++): ?>
        <div class="item-card">
            <div class="item-image"></div>
            <div class="item-info">
                <h3>Item <?= $i ?></h3>
                <p>Borrowed Info...</p>
                <button>Return</button>
            </div>
        </div>
        <?php endfor; ?>
    </div>
</div>